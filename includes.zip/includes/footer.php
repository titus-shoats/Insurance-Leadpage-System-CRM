
<footer >
    <ul  class="list-inline">
        <li><a class="footer_links" href="../">Home</a> </li>
        <li><a  class="footer_links" href="./faq.php">FAQ</a></li>
        <li><a   class="footer_links" href="./privacy.php">Privacy Policy</a></li>
        <li><a  class="footer_links" href="./terms.php">Terms Of Use</a></li>
        <li><a  class="footer_links" href="./unsubscribe.php">Unsubscribe</a></li>


    </ul>
</footer>


</section>




</body>

</html>